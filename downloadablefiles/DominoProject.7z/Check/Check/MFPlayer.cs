﻿using System.Collections.Generic;

namespace DominoC
{
    class MFPlayer
    {
        static public string PlayerName = "Еникеев Ильдар";
        static private List<MTable.SBone> lHand;


        //=== Готовые функции =================
        // инициализация игрока
        static public void Initialize()
        {
            lHand = new List<MTable.SBone>();
        }

        // Вывод на экран
        static public void PrintAll()
        { MTable.PrintAll(lHand); }

        // дать количество доминушек
        static public int GetCount()
        { return lHand.Count; }

        //=== Функции для разработки =================
        // добавить доминушку в свою руку
        static public void AddItem(MTable.SBone sb)
        {
            lHand.Add(sb);
        }

        // дать сумму очков на руке
        static public int GetScore()
        {
            int sum = 0;
            if ((lHand.Count == 1 && lHand[0].First == 0) && lHand[0].Second == 0)
            {
                sum = 25;
            }
            else
            {
                foreach (MTable.SBone t in lHand)
                {
                    sum += t.First;
                    sum += t.Second;
                }
            }
            return sum;
        }
        static private void ins(List<MTable.SBone> DomPac, List<MTable.SBone> BoneList, out MTable.SBone sb, out bool End, out bool bat)
        {
            MTable.SBone tmp;
            tmp.First = 7;
            tmp.Second = 7;
            sb = tmp;
            End = false;
            bat = true;
            int i;
            for (i = 0; i < lHand.Count; i++)
            {
                if (DomPac[i].Second == BoneList[0].First || DomPac[i].First == BoneList[BoneList.Count - 1].Second)
                {
                    sb = DomPac[i];

                    if (DomPac[i].Second == BoneList[0].First)
                    {
                        End = false;
                    }
                    else
                    {
                        End = true;
                    }
                    bat = false;

                    lHand.Remove(DomPac[i]);
                    break;
                }
                else
                {
                    if (DomPac[i].First == BoneList[0].First || DomPac[i].Second == BoneList[BoneList.Count - 1].Second)
                    {
                        sb = DomPac[i];

                        if (DomPac[i].First == BoneList[0].First)
                        {
                            End = false;
                        }
                        else
                        {
                            End = true;
                        }
                        lHand.Remove(DomPac[i]);
                        bat = false;
                        break;
                    }

                }
            }
        }
        static private void PacSort(List<MTable.SBone> DomPac)
        {
            int dinedx = 0, i, j, maxsum, maxi;
            MTable.SBone tmp;
            for (i = 0; i < DomPac.Count; i++)
            {
                if (DomPac[i].First == DomPac[i].Second)
                {
                    tmp = DomPac[i];
                    DomPac[i] = DomPac[dinedx];
                    DomPac[dinedx++] = tmp;
                }
            }
            for (i = dinedx; i < DomPac.Count; i++)
            {
                maxsum = 0;
                for (j = i; j < DomPac.Count; j++)
                {
                    if (DomPac[j].First + DomPac[j].Second > maxsum)
                    {
                        maxsum = DomPac[j].First + DomPac[j].Second;
                        maxi = j;
                    }
                    tmp = DomPac[i];
                    DomPac[i] = DomPac[j];
                    DomPac[j] = tmp;
                }
            }
        }
        // сделать ход
        static public bool MakeStep(out MTable.SBone sb, out bool End)
        {
            List<MTable.SBone> BoneList = new List<MTable.SBone>();
            List<MTable.SBone> DomPac = new List<MTable.SBone>();
            BoneList = MTable.GetGameCollection();
            int i; bool bat;
            MTable.SBone msb;
            MTable.SBone FalseValue;
            FalseValue.First = 7;
            FalseValue.Second = 7;
            sb = FalseValue;
            End = false;
            MTable.PrintAll(BoneList);
            do
            {
                bat = true;
                for (i = 0; i < lHand.Count; i++)
                {
                    if (lHand[i].Second == BoneList[0].First || lHand[i].First == BoneList[BoneList.Count - 1].Second)
                    {
                        DomPac.Add(lHand[i]);
                    }
                    else
                    {
                        if (lHand[i].First == BoneList[0].First || lHand[i].Second == BoneList[BoneList.Count - 1].Second)
                        {
                            DomPac.Add(lHand[i]);
                        }

                    }
                }
                if (DomPac.Count != 0)
                {
                    PacSort(DomPac);
                    ins(DomPac, BoneList, out sb, out End, out bat);
                }
                if (MTable.GetShopCount() != 0 && bat)
                {
                    MTable.GetFromShop(out msb);
                    AddItem(msb);
                }
            } while (bat && MTable.GetShopCount() == 0);
            if (bat)
            {

                return false;
            }
            else
            {
                return true;
            }
        }

    }
}
