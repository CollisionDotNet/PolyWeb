﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DominoC
{
    class MSPlayer
    {
        static public string PlayerName = "Бывалый";
        static private List<MTable.SBone> lHand;

        // инициализация игрока
        static public void Initialize()
        {
            lHand = new List<MTable.SBone>();
        }

        // добавить доминушку в свою руку
        static public void AddItem(MTable.SBone sb)
        { lHand.Add(sb); }

        // Вывод на экран
        static public void PrintAll()
        { MTable.PrintAll(lHand); }

        // дать сумму очков на руке
        static public int GetScore()
        {
            int intScore = 0;
            MTable.SBone sb;

            if (lHand.Count == 1)
            {
                sb = lHand[0];
                if (sb.First == 0 && sb.Second == 0) return 25;
            }
            foreach (MTable.SBone sb1 in lHand)
            { intScore += sb1.First + sb1.Second; }
            return intScore;
        }

        // дать количество доминушек
        static public int GetCount()
        { return lHand.Count; }

        // сделать ход
        static public bool MakeStep(out MTable.SBone sb, out bool End)
        {
            MTable.SBone sbFirst, sbLast;
            List<MTable.SBone> lGame = MTable.GetGameCollection();
            int intC;

            sbFirst = lGame[0];
            sbLast = lGame[lGame.Count - 1];

            for (intC = 0; intC < lHand.Count; intC++)
            {
                if (lHand[intC].Second == sbFirst.First || lHand[intC].First == sbFirst.First)
                {
                    sb = lHand[intC];
                    lHand.RemoveAt(intC);
                    End = false;
                    return true;
                }
                else if (lHand[intC].Second == sbLast.Second || lHand[intC].First == sbLast.Second)
                {
                    sb = lHand[intC];
                    lHand.RemoveAt(intC);
                    End = true;
                    return true;
                }
            }

            // нет подходящей доминуки - берем из базара
            MTable.SBone sbTemp;
            while (MTable.GetFromShop(out sbTemp))
            {
                if (sbTemp.Second == sbFirst.First || sbTemp.First == sbFirst.First)
                {
                    sb = sbTemp;
                    End = false;
                    return true;
                }
                else if (sbTemp.Second == sbLast.Second || sbTemp.First == sbLast.Second)
                {
                    sb = sbTemp;
                    End = true;
                    return true;
                }
                lHand.Add(sbTemp);
            }
            // ничего не нашли
            sb.First = 0;
            sb.Second = 0;
            End = true;
            return false;
        }
    }
}
