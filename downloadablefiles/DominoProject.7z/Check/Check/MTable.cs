﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;

namespace DominoC
{
    public class MTable
    {
        static void Main(string[] args)
        {
            string path = @"C:\Users\User\Desktop\dsfsdf\";
            Launch(1, 50, path, "первый", "второй");
        }

        public const int timeout = 5000; // максимальное время для шага в ms

        // количество доминошек в руке в начале игры
        public const int conStartCount = 7;
        // Состояние игры
        public enum EFinish { Play = 0, First, Second, Lockdown }; // играем, выиграл первый, выиграл второй, рыба
        public static StreamWriter writer;
        // Доминушка
        public struct SBone
        {
            public ushort First;
            public ushort Second;

            public void Exchange()
            {
                ushort shrTemp = First;
                First = Second;
                Second = shrTemp;
            }

            // cheater check
            public SBone Clone()
            {
                SBone clone = new SBone();
                clone.First = this.First;
                clone.Second = this.Second;
                return clone;
            }

            public bool toCompare(SBone bone)
            {
                return this.First == bone.First && this.Second == bone.Second
                    || this.Second == bone.First && this.First == bone.Second;
            }
        }

        // "Базар" доминошек
        static private List<SBone> lBoneyard;
        //Текущий расклад на столе
        static private List<SBone> lGame;
        // Количество взятых доминушек игроком за прошлый \ текущий ход 
        static private int intLastTaken, intTaken;
        // Генератор случайных чисел
        static public Random rnd = new Random();

        // cheater check
        static private List<SBone> lastFirstHand;
        static private List<SBone> lastSecondHand;
        // кто сейчас ходит
        static private bool blnFirst;

        //***********************************************************************
        // Инициализация игры
        //***********************************************************************
        static public void Initialize()
        {
            SBone sb;

            //   rnd = new Random();
            // Очищаем коллекции в этом модуле
            lBoneyard = new List<SBone>();
            lGame = new List<SBone>();

            // Формирование базара
            for (ushort shrC = 0; shrC <= 6; shrC++)
                for (ushort shrB = shrC; shrB <= 6; shrB++)
                {
                    sb.First = shrC;
                    sb.Second = shrB;
                    lBoneyard.Add(sb);
                }

            // Инициализация игроков
            MFPlayer.Initialize();
            MSPlayer.Initialize();
        }

        //***********************************************************************
        // Получение случайной доминошки (sb) из базара
        // Возвращает FALSE, если базар пустой
        //***********************************************************************
        static public bool GetFromShop(out SBone sb)
        {
            int intN;
            sb.First = 7; sb.Second = 7;

            if (lBoneyard.Count == 0) return false;

            // Подсчет количества взятых доминушек одним игроком за текущий ход
            intTaken += 1;
            // определяем случайным образом доминушку из базара
            intN = rnd.Next(lBoneyard.Count - 1);
            sb = lBoneyard[intN];
            // удаляем ее из базара
            lBoneyard.RemoveAt(intN);

            // cheater check
            if (blnFirst)
                lastFirstHand.Add(sb.Clone());
            else
                lastSecondHand.Add(sb.Clone());

            return true;
        }

        //***********************************************************************
        // Возвращает количество оставшихся доминошек в базаре
        //***********************************************************************
        static public int GetShopCount()
        {
            return lBoneyard.Count;
        }

        //***********************************************************************
        // Возвращает количество взятых игроком доминушек за текущий ход
        //***********************************************************************
        static public int GetTaken()
        { return intLastTaken; }

        //***********************************************************************
        // Возвращает информацию о текущем раскладе на столе
        //***********************************************************************
        static public List<SBone> GetGameCollection()
        { return lGame.ToList(); }

        //***********************************************************************
        // Раздача доминошек обоим игрокам в начале игры
        //***********************************************************************
        static public void GetHands()
        {
            SBone sb;
            for (int intC = 0; intC < conStartCount; intC++)
            {
                if (GetFromShop(out sb))
                {
                    MFPlayer.AddItem(sb);
                    writer.WriteLine("1-" + sb.First + ":" + sb.Second + ","); // Записываем логи начальной раздачи каждому игроку по очереди
                }
                intTaken = 0;
                blnFirst = !blnFirst; // cheater check
                if (GetFromShop(out sb))
                {
                    MSPlayer.AddItem(sb);
                    writer.WriteLine("2-" + sb.First + ":" + sb.Second + ",");
                }
                blnFirst = !blnFirst; // cheater check
                intTaken = 0;
            }
        }

        //***********************************************************************
        // Вывод на экран всех элементов коллекции colX
        //***********************************************************************
        static public void PrintAll(List<SBone> lItems)
        {
            foreach (SBone sb in lItems)
                writer.Write(sb.First + ":" + sb.Second + ",");
            writer.WriteLine();
        }

        //***********************************************************************
        // Положить доминушку на стол
        //***********************************************************************
        static public bool SetBone(SBone sb, bool blnEnd)
        {
            // cheater check
            if (!CheckIsInHand(sb))
                return false;
            RemoveFromHand(sb);

            SBone sbT;
            if (blnEnd)
            {
                sbT = lGame[lGame.Count - 1];
                if (sbT.Second == sb.First)
                {
                    lGame.Add(sb);
                    return true;
                }
                else if (sbT.Second == sb.Second)
                {
                    sb.Exchange();
                    lGame.Add(sb);
                    return true;
                }
                else
                    return false;
            }
            else
            {
                sbT = lGame[0];
                if (sbT.First == sb.Second)
                {
                    lGame.Insert(0, sb);
                    return true;
                }
                else if (sbT.First == sb.First)
                {
                    sb.Exchange();
                    lGame.Insert(0, sb);
                    return true;
                }
                else
                    return false;
            }
        }

        public static ((int, int)[], int) Launch(int startNum, int count, string path, string FPlayerName, string SPlayerName) // Бывший Main()
        {
            ((int, int)[] result, int cheaterNum) output = (new (int, int)[count], 0);
            for (int i = 0; i < count; i++)
            {
                lastFirstHand = new List<SBone>();
                lastSecondHand = new List<SBone>();

                string curFileName = path + "\\" + (i + startNum + 1).ToString() + ".txt";
                FileStream stream = File.Create(curFileName);
                stream.Close();
                writer = new StreamWriter(curFileName);
                // результат текущего хода игроков =TRUE, если ход состоялся
                bool blnFRes, blnSRes;
                // признак окончания игры
                EFinish efFinish = EFinish.Play;
                // сообщения о результате игры
                // количество доминушек в базаре, нужно для определения корректности хода игрока
                int intBoneyard = 0;
                // Чем ходить
                SBone sb = new SBone();
                // куда ходить
                bool blnEnd = false;
                writer.WriteLine(FPlayerName);
                writer.WriteLine(SPlayerName);
                // Инициализация игры
                Initialize();
                // Первым ходит первый игрок
                blnFirst = true;

                // Раздача доминошек в начале игры
                GetHands();
                // первая доминушка - первая из базара
                // определяем случайным образом доминушку из базара
                int intN = rnd.Next(lBoneyard.Count - 1);
                lGame.Add(lBoneyard[intN]);
                lBoneyard.RemoveAt(intN);
                // вывод на экран начального состояния игры
                writer.WriteLine("*");
                writer.WriteLine("~");

                PrintAll(lGame);
                MFPlayer.PrintAll();
                MSPlayer.PrintAll();

                blnFRes = true;
                blnSRes = true;

                intBoneyard = lBoneyard.Count;
                Thread thread;
                //-----------------------------------------------------------------
                // ИГРА
                do
                {
                    // кто ходит? ---- Ходит первый игрок
                    if (blnFirst)
                    {
                        writer.WriteLine("~");

                        // количество взятых доминушек
                        intLastTaken = intTaken;
                        intTaken = 0;
                        // ход первого игрока
                        intBoneyard = lBoneyard.Count;

                        thread = new Thread(() => { blnFRes = MFPlayer.MakeStep(out sb, out blnEnd); });
                        thread.IsBackground = true;
                        thread.Start();
                        if (!thread.Join(timeout))
                        {
                            writer.Write("1!");
                            writer.Write("Цикл");
                            writer.Write("Зацикливание. Метод не отвечает дольше " + timeout + " ms");
                            writer.Close();
                            output.result = null;
                            output.cheaterNum = 1;
                            Console.WriteLine("Цикл 1");
                            Console.ReadLine();
                            return output;
                        }

                        // если ход сделан
                        if (blnFRes)
                        {
                            // пристраиваем доминушку
                            if (SetBone(sb, blnEnd) == false)
                            {
                                writer.Write("1!");
                                writer.Close();
                                output.result = null;
                                output.cheaterNum = 1;
                                Console.WriteLine("Чит 1");
                                Console.ReadLine();
                                return output;
                            }
                        }
                        // если ход не сделан
                        else if (intBoneyard == lBoneyard.Count && intBoneyard > 0)
                        {
                            writer.Write("1!");
                            writer.Close();
                            output.result = null;
                            output.cheaterNum = 1;
                            Console.WriteLine("Чит 1");
                            Console.ReadLine();
                            return output;
                        }

                        if (blnFRes == false && blnSRes == false)
                            // рыба
                            efFinish = EFinish.Lockdown;
                        else if (blnFRes == true)
                            // если нет домино, то я выиграл
                            if (MFPlayer.GetCount() == 0) efFinish = EFinish.First;
                    }
                    // кто ходит? ---- Ходит вторый игрок
                    else
                    {
                        writer.WriteLine("~");
                        // количество взятых доминушек
                        intLastTaken = intTaken;
                        intTaken = 0;
                        // ход первого игрока
                        intBoneyard = lBoneyard.Count;

                        thread = new Thread(() => { blnSRes = MSPlayer.MakeStep(out sb, out blnEnd); });
                        thread.IsBackground = true;
                        thread.Start();
                        if (!thread.Join(timeout))
                        {
                            writer.Write("2!");
                            writer.Write("Цикл");
                            writer.Write("Зацикливание. Метод не отвечает дольше " + timeout + " ms");
                            writer.Close();
                            output.result = null;
                            output.cheaterNum = 2;
                            Console.WriteLine("Цикл 2");
                            Console.ReadLine();
                            return output;
                        }

                        // если ход сделан
                        if (blnSRes)
                        {
                            // пристраиваем доминушку
                            if (SetBone(sb, blnEnd) == false)
                            {
                                writer.Write("2!");
                                writer.Close();
                                output.result = null;
                                output.cheaterNum = 2;
                                Console.WriteLine("Чит 2");
                                Console.ReadLine();
                                return output;
                            }
                        }
                        // если ход не сделан
                        else if (intBoneyard == lBoneyard.Count && intBoneyard > 0)
                        {
                            writer.Write("2!");
                            writer.Close();
                            output.result = null;
                            output.cheaterNum = 2;
                            Console.WriteLine("Чит 2");
                            Console.ReadLine();
                            return output;
                        }

                        if (blnFRes == false && blnSRes == false)
                            // рыба
                            efFinish = EFinish.Lockdown;
                        else if (blnSRes == true)
                            // если нет домино, то я выиграл
                            if (MSPlayer.GetCount() == 0) efFinish = EFinish.Second;
                    }
                    // после хода вывести данные на столе--------------------------------------------------------
                    PrintAll(lGame);
                    MFPlayer.PrintAll();
                    MSPlayer.PrintAll();
                    // будет ходить другой игрок
                    blnFirst = !blnFirst;
                    intBoneyard = lBoneyard.Count;
                }
                while (efFinish == EFinish.Play);
                // результат текущей игры
                writer.Write((int)efFinish);

                writer.Write(":" + GetScore(lastFirstHand) + ":" + GetScore(lastSecondHand));
                writer.Close();
                output.result[i] = (GetScore(lastFirstHand), GetScore(lastSecondHand));
                Console.WriteLine(GetScore(lastFirstHand) + " - " + GetScore(lastSecondHand));
            }
            return output;
        }

        private static bool CheckIsInHand(SBone bone)
        {
            return FindIndex(bone) != -1;
        }

        private static int FindIndex(SBone bone)
        {
            int i = 0;
            if (blnFirst)
                foreach (SBone b in lastFirstHand)
                {
                    if (b.toCompare(bone))
                        return i;
                    i++;
                }
            else
                foreach (SBone b in lastSecondHand)
                {
                    if (b.toCompare(bone))
                        return i;
                    i++;
                }
            return -1;
        }

        private static void RemoveFromHand(SBone bone)
        {
            int ind = FindIndex(bone);
            if (blnFirst)
                lastFirstHand.RemoveAt(ind);
            else
                lastSecondHand.RemoveAt(ind);
        }

        static public int GetScore(List<SBone> lHand)
        {
            int intScore = 0;

            if (lHand.Count == 1)
            {
                MTable.SBone sb = lHand[0];
                if (sb.First == 0 && sb.Second == 0) return 25;
            }
            foreach (MTable.SBone sb1 in lHand)
            { intScore += sb1.First + sb1.Second; }
            return intScore;
        }
    }
}